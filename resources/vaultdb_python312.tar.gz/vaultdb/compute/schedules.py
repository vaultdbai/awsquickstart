"""Schedules define the intervals at which periodic tasks run."""

try:
    from celery.schedules import crontab, schedule

except:
    import re
    from typing import Any, Callable, Sequence
    from collections.abc import Iterable

    CRON_PATTERN_INVALID = """\
    Invalid crontab pattern.  Valid range is {min}-{max}. \
    '{value}' was found.\
    """

    CRON_INVALID_TYPE = """\
    Argument cronspec needs to be of any of the following types: \
    int, str, or an iterable type. {type!r} was given.\
    """

    CRON_REPR = """\
    <crontab: {0._orig_minute} {0._orig_hour} {0._orig_day_of_month} {0._orig_month_of_year} \
    {0._orig_day_of_week} (m/h/dM/MY/d)>\
    """

    DAYNAMES = "sun", "mon", "tue", "wed", "thu", "fri", "sat"
    WEEKDAYS = dict(zip(DAYNAMES, range(7)))

    MONTHNAMES = (
        "jan",
        "feb",
        "mar",
        "apr",
        "may",
        "jun",
        "jul",
        "aug",
        "sep",
        "oct",
        "nov",
        "dec",
    )
    YEARMONTHS = dict(zip(MONTHNAMES, range(1, 13)))

    def weekday(name: str) -> int:
        """Return the position of a weekday: 0 - 7, where 0 is Sunday.

        Example:
            >>> weekday('sunday'), weekday('sun'), weekday('mon')
            (0, 0, 1)
        """
        abbreviation = name[0:3].lower()
        try:
            return WEEKDAYS[abbreviation]
        except KeyError:
            # Show original day name in exception, instead of abbr.
            raise KeyError(name)

    def yearmonth(name: str) -> int:
        """Return the position of a month: 1 - 12, where 1 is January.

        Example:
            >>> yearmonth('january'), yearmonth('jan'), yearmonth('may')
            (1, 1, 5)
        """
        abbreviation = name[0:3].lower()
        try:
            return YEARMONTHS[abbreviation]
        except KeyError:
            # Show original day name in exception, instead of abbr.
            raise KeyError(name)

    def cronfield(s: str) -> str:
        return "*" if s is None else s

    class ParseException(Exception):
        """Raised by :class:`crontab_parser` when the input can't be parsed."""

    class schedule(object):
        """Schedule for periodic task.

        Arguments:
            run_every (float, ~datetime.timedelta): Time interval.
            relative (bool):  If set to True the run time will be rounded to the
                resolution of the interval.
        """

        relative: bool = False

        def __init__(self, run_every: float, relative: bool = False) -> None:
            self.run_every = run_every
            self.relative = relative

    class crontab_parser:
        """Parser for Crontab expressions.

        Any expression of the form 'groups'
        (see BNF grammar below) is accepted and expanded to a set of numbers.
        These numbers represent the units of time that the Crontab needs to
        run on:

        .. code-block:: bnf

            digit   :: '0'..'9'
            dow     :: 'a'..'z'
            number  :: digit+ | dow+
            steps   :: number
            range   :: number ( '-' number ) ?
            numspec :: '*' | range
            expr    :: numspec ( '/' steps ) ?
            groups  :: expr ( ',' expr ) *

        The parser is a general purpose one, useful for parsing hours, minutes and
        day of week expressions.  Example usage:

        .. code-block:: pycon

            >>> minutes = crontab_parser(60).parse('*/15')
            [0, 15, 30, 45]
            >>> hours = crontab_parser(24).parse('*/4')
            [0, 4, 8, 12, 16, 20]
            >>> day_of_week = crontab_parser(7).parse('*')
            [0, 1, 2, 3, 4, 5, 6]

        It can also parse day of month and month of year expressions if initialized
        with a minimum of 1.  Example usage:

        .. code-block:: pycon

            >>> days_of_month = crontab_parser(31, 1).parse('*/3')
            [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31]
            >>> months_of_year = crontab_parser(12, 1).parse('*/2')
            [1, 3, 5, 7, 9, 11]
            >>> months_of_year = crontab_parser(12, 1).parse('2-12/2')
            [2, 4, 6, 8, 10, 12]

        The maximum possible expanded value returned is found by the formula:

            :math:`max_ + min_ - 1`
        """

        ParseException = ParseException

        _range = r"(\w+?)-(\w+)"
        _steps = r"/(\w+)?"
        _star = r"\*"

        def __init__(self, max_: int = 60, min_: int = 0):
            self.max_ = max_
            self.min_ = min_
            self.pats: tuple[tuple[re.Pattern, Callable], ...] = (
                (re.compile(self._range + self._steps), self._range_steps),
                (re.compile(self._range), self._expand_range),
                (re.compile(self._star + self._steps), self._star_steps),
                (re.compile("^" + self._star + "$"), self._expand_star),
            )

        def parse(self, spec: str) -> set[int]:
            acc = set()
            for part in spec.split(","):
                if not part:
                    raise self.ParseException("empty part")
                acc |= set(self._parse_part(part))
            return acc

        def _parse_part(self, part: str) -> list[int]:
            for regex, handler in self.pats:
                m = regex.match(part)
                if m:
                    return handler(m.groups())
            return self._expand_range((part,))

        def _expand_range(self, toks: Sequence[str]) -> list[int]:
            fr = self._expand_number(toks[0])
            if len(toks) > 1:
                to = self._expand_number(toks[1])
                if to < fr:  # Wrap around max_ if necessary
                    return list(range(fr, self.min_ + self.max_)) + list(
                        range(self.min_, to + 1)
                    )
                return list(range(fr, to + 1))
            return [fr]

        def _range_steps(self, toks: Sequence[str]) -> list[int]:
            if len(toks) != 3 or not toks[2]:
                raise self.ParseException("empty filter")
            return self._expand_range(toks[:2])[:: int(toks[2])]

        def _star_steps(self, toks: Sequence[str]) -> list[int]:
            if not toks or not toks[0]:
                raise self.ParseException("empty filter")
            return self._expand_star()[:: int(toks[0])]

        def _expand_star(self, *args: Any) -> list[int]:
            return list(range(self.min_, self.max_ + self.min_))

        def _expand_number(self, s: str) -> int:
            if isinstance(s, str) and s[0] == "-":
                raise self.ParseException("negative numbers not supported")
            try:
                i = int(s)
            except ValueError:
                try:
                    i = yearmonth(s)
                except KeyError:
                    try:
                        i = weekday(s)
                    except KeyError:
                        raise ValueError(f"Invalid weekday literal {s!r}.")

            max_val = self.min_ + self.max_ - 1
            if i > max_val:
                raise ValueError(f"Invalid end range: {i} > {max_val}.")
            if i < self.min_:
                raise ValueError(f"Invalid beginning range: {i} < {self.min_}.")

            return i

    class crontab(object):
        """Crontab schedule.

        A Crontab can be used as the ``run_every`` value of a
        periodic task entry to add :manpage:`crontab(5)`-like scheduling.

        Like a :manpage:`cron(5)`-job, you can specify units of time of when
        you'd like the task to execute.  It's a reasonably complete
        implementation of :command:`cron`'s features, so it should provide a fair
        degree of scheduling needs.

        You can specify a minute, an hour, a day of the week, a day of the
        month, and/or a month in the year in any of the following formats:

        .. attribute:: minute

            - A (list of) integers from 0-59 that represent the minutes of
            an hour of when execution should occur; or
            - A string representing a Crontab pattern.  This may get pretty
            advanced, like ``minute='*/15'`` (for every quarter) or
            ``minute='1,13,30-45,50-59/2'``.

        .. attribute:: hour

            - A (list of) integers from 0-23 that represent the hours of
            a day of when execution should occur; or
            - A string representing a Crontab pattern.  This may get pretty
            advanced, like ``hour='*/3'`` (for every three hours) or
            ``hour='0,8-17/2'`` (at midnight, and every two hours during
            office hours).

        .. attribute:: day_of_week

            - A (list of) integers from 0-6, where Sunday = 0 and Saturday =
            6, that represent the days of a week that execution should
            occur.
            - A string representing a Crontab pattern.  This may get pretty
            advanced, like ``day_of_week='mon-fri'`` (for weekdays only).
            (Beware that ``day_of_week='*/2'`` does not literally mean
            'every two days', but 'every day that is divisible by two'!)

        .. attribute:: day_of_month

            - A (list of) integers from 1-31 that represents the days of the
            month that execution should occur.
            - A string representing a Crontab pattern.  This may get pretty
            advanced, such as ``day_of_month='2-30/2'`` (for every even
            numbered day) or ``day_of_month='1-7,15-21'`` (for the first and
            third weeks of the month).

        .. attribute:: month_of_year

            - A (list of) integers from 1-12 that represents the months of
            the year during which execution can occur.
            - A string representing a Crontab pattern.  This may get pretty
            advanced, such as ``month_of_year='*/3'`` (for the first month
            of every quarter) or ``month_of_year='2-12/2'`` (for every even
            numbered month).

        .. attribute:: nowfun

            Function returning the current date and time
            (:class:`~datetime.datetime`).

        .. attribute:: app

            The Celery app instance.

        It's important to realize that any day on which execution should
        occur must be represented by entries in all three of the day and
        month attributes.  For example, if ``day_of_week`` is 0 and
        ``day_of_month`` is every seventh day, only months that begin
        on Sunday and are also in the ``month_of_year`` attribute will have
        execution events.  Or, ``day_of_week`` is 1 and ``day_of_month``
        is '1-7,15-21' means every first and third Monday of every month
        present in ``month_of_year``.
        """

        def __init__(
            self,
            minute: str = "*",
            hour: str = "*",
            day_of_week: str = "*",
            day_of_month: str = "*",
            month_of_year: str = "*",
            **kwargs: Any,
        ) -> None:
            self._orig_minute = cronfield(minute)
            self._orig_hour = cronfield(hour)
            self._orig_day_of_week = cronfield(day_of_week)
            self._orig_day_of_month = cronfield(day_of_month)
            self._orig_month_of_year = cronfield(month_of_year)
            self._orig_kwargs = kwargs
            self.hour = self._expand_cronspec(hour, 24)
            self.minute = self._expand_cronspec(minute, 60)
            self.day_of_week = self._expand_cronspec(day_of_week, 7)
            self.day_of_month = self._expand_cronspec(day_of_month, 31, 1)
            self.month_of_year = self._expand_cronspec(month_of_year, 12, 1)
            super().__init__(**kwargs)

        @classmethod
        def from_string(cls, crontab: str) -> crontab:
            """
            Create a Crontab from a cron expression string. For example ``crontab.from_string('* * * * *')``.

            .. code-block:: text

                ┌───────────── minute (0–59)
                │ ┌───────────── hour (0–23)
                │ │ ┌───────────── day of the month (1–31)
                │ │ │ ┌───────────── month (1–12)
                │ │ │ │ ┌───────────── day of the week (0–6) (Sunday to Saturday)
                * * * * *
            """
            minute, hour, day_of_month, month_of_year, day_of_week = crontab.split(" ")
            return cls(minute, hour, day_of_week, day_of_month, month_of_year)

        @staticmethod
        def _expand_cronspec(
            cronspec: int | str | Iterable, max_: int, min_: int = 0
        ) -> set[Any]:
            """Expand cron specification.

            Takes the given cronspec argument in one of the forms:

            .. code-block:: text

                int         (like 7)
                str         (like '3-5,*/15', '*', or 'monday')
                set         (like {0,15,30,45}
                list        (like [8-17])

            And convert it to an (expanded) set representing all time unit
            values on which the Crontab triggers.  Only in case of the base
            type being :class:`str`, parsing occurs.  (It's fast and
            happens only once for each Crontab instance, so there's no
            significant performance overhead involved.)

            For the other base types, merely Python type conversions happen.

            The argument ``max_`` is needed to determine the expansion of
            ``*`` and ranges.  The argument ``min_`` is needed to determine
            the expansion of ``*`` and ranges for 1-based cronspecs, such as
            day of month or month of year.  The default is sufficient for minute,
            hour, and day of week.
            """
            if isinstance(cronspec, int):
                result = {cronspec}
            elif isinstance(cronspec, str):
                result = crontab_parser(max_, min_).parse(cronspec)
            elif isinstance(cronspec, set):
                result = cronspec
            elif isinstance(cronspec, Iterable):
                result = set(cronspec)  # type: ignore
            else:
                raise TypeError(CRON_INVALID_TYPE.format(type=type(cronspec)))

            # assure the result does not precede the min or exceed the max
            for number in result:
                if number >= max_ + min_ or number < min_:
                    raise ValueError(
                        CRON_PATTERN_INVALID.format(
                            min=min_, max=max_ - 1 + min_, value=number
                        )
                    )
            return result

        def __repr__(self) -> str:
            return CRON_REPR.format(self)

        def __eq__(self, other: Any) -> bool:
            if isinstance(other, crontab):
                return (
                    other.month_of_year == self.month_of_year
                    and other.day_of_month == self.day_of_month
                    and other.day_of_week == self.day_of_week
                    and other.hour == self.hour
                    and other.minute == self.minute
                    and super().__eq__(other)
                )
            return NotImplemented


__all__ = ["crontab", "schedule"]
