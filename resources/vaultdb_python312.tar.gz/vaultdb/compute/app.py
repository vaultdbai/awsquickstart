import os
App = None
try:
    
    from celery import Celery

    redis_broker = os.getenv("redis_broker", "redis:6379")

    App = Celery(
        "tasks", broker=f"redis://{redis_broker}/0", backend=f"redis://{redis_broker}/0"
    )
except:
    class App(object):
        """docstring for Task."""
        def __init__(self, arg):
            super(App, self).__init__()
        
        def conf(self):
            """Vaultdb App configuration."""

__all__ = ["App"]
